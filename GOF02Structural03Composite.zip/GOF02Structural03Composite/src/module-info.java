module GOF02Structural03Composite {
}