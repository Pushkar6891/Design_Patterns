package com.designpatterns.kk;

// This is a leaf
// EmployeeServiceImpl and AdminServiceImpl are independent and not related
public class EmployeeServiceImpl implements Service {

	@Override
	public void service(String serviceType) {
		System.out.println(serviceType + " for Employee");
	}

}
