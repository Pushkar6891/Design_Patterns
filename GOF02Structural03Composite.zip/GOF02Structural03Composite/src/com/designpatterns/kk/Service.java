package com.designpatterns.kk;

public interface Service {
	public abstract void service(String serviceType);
}
