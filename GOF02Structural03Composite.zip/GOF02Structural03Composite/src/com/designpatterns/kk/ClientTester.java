package com.designpatterns.kk;

public class ClientTester {

	public static void main(String[] args) {

		Service employeeService1 = new EmployeeServiceImpl();
		Service employeeService2 = new EmployeeServiceImpl();

		Service adminService1 = new AdminServiceImpl();
		Service adminService2 = new AdminServiceImpl();// not adding adminService2 initially

		CompositeServiceProvider compositeServiceProvider = new CompositeServiceProvider();

		compositeServiceProvider.addService(employeeService1);
		compositeServiceProvider.addService(employeeService2);
		compositeServiceProvider.addService(adminService1);

		compositeServiceProvider.service("Registration Service");

		compositeServiceProvider.deleteService(employeeService1);

		compositeServiceProvider.addService(adminService2);// adding adminService2 now

		System.out.println("=================");
		compositeServiceProvider.service("Logout Service");

		compositeServiceProvider.clearServices();
		System.out.println("=================");
		compositeServiceProvider.addService(employeeService1);
		compositeServiceProvider.service("Update Service");
		System.out.println("=================");
	}

}
