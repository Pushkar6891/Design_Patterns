module GOF03Behavioural08State {
}