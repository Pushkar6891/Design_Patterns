package com.designpatterns.kk;

public interface State {
	public abstract void doAction();
}
