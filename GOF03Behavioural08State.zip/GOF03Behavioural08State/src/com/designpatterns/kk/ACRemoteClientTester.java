package com.designpatterns.kk;

public class ACRemoteClientTester {

	public static void main(String[] args) {

		ACContextImpl acContext = new ACContextImpl();
		State acStartState = new ACStartStateImpl();
		acContext.setState(acStartState);
		acContext.doAction();

		System.out.println("=======================");

		State acStopState = new ACStopStateImpl();
		acContext.setState(acStopState);
		acContext.doAction();

		System.out.println("=======================");
	}

}
