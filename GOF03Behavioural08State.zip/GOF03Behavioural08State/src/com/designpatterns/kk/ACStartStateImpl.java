package com.designpatterns.kk;

public class ACStartStateImpl implements State {

	@Override
	public void doAction() {
		System.out.println("AC is turned ON");
	}

}
