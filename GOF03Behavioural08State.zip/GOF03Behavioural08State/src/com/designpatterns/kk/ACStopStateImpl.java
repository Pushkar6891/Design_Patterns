package com.designpatterns.kk;

public class ACStopStateImpl implements State {

	@Override
	public void doAction() {
		System.out.println("AC is turned OFF");
	}

}
