module J2EE07ServiceLocator {
}