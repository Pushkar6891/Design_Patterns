package com.designpatterns.servicelocator;

public class ClientTester {

	public static void main(String[] args) {

		Service service = Locator.getService("EmployeeService");
		service.execute();
		service = Locator.getService("CustomerService");
		service.execute();

	}

}
