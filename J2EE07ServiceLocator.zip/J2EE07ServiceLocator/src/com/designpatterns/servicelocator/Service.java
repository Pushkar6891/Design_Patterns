package com.designpatterns.servicelocator;

public interface Service {
    public String getServiceName();
    public void execute();
}