module GOF03Behavioural02Command {
}