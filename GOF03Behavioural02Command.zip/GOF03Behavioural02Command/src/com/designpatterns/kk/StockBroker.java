package com.designpatterns.kk;

import java.util.ArrayList;
import java.util.List;

// StockBroker will execute command based on the stock
public class StockBroker {

	private List<Order> orderList = new ArrayList<Order>();

	public void placeOrder(Order order) {
		orderList.add(order);
	}

	public void executeOrders() {
		for (Order order : orderList) {
			order.execute();
		}
		orderList.clear();
	}
}
