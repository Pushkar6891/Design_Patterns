package com.designpatterns.kk;

public class BuyOrderImpl implements Order {

	private Stock stock;
	
	
	public BuyOrderImpl(Stock stock) {
		this.stock = stock;
	}


	@Override
	public void execute() {
		stock.buyStock();
	}

}
