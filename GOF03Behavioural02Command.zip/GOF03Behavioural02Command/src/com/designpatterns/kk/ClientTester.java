package com.designpatterns.kk;

public class ClientTester {

	public static void main(String[] args) {

		// Request Object
		Stock stock = new Stock();

		// Request Object(stock) wrapped inside Command Object(BuyOrderImpl and SellOrderImpl)
		BuyOrderImpl buyOrderImpl = new BuyOrderImpl(stock);
		SellOrderImpl sellOrderImpl = new SellOrderImpl(stock);

		// Command Object(BuyOrderImpl and SellOrderImpl) passed to Invoker Object(StockBroker)
		StockBroker stockBroker = new StockBroker();
		stockBroker.placeOrder(buyOrderImpl);
		stockBroker.placeOrder(sellOrderImpl);
		
		// Execute the list of orders
		stockBroker.executeOrders();
	}

}
