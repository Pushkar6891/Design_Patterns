package com.designpatterns.kk;

public class Stock {

	private String stockName = "Google Share";
	private int stockQuantity = 20;

	public void buyStock() {
		System.out.println("Buying Stock : " + "Stock Name : " + stockName + " Stock Quantity : " + stockQuantity);
	}

	public void sellStock() {
		System.out.println("Selling Stock : " + "Stock Name : " + stockName + " Stock Quantity : " + stockQuantity);
	}
}
