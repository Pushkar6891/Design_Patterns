package com.designpatterns.kk;
// This is a Command interface
public interface Order {
	public abstract void execute();
}
