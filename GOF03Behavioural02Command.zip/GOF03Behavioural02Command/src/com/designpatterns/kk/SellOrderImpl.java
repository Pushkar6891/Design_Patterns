package com.designpatterns.kk;

public class SellOrderImpl implements Order {

	private Stock stock;
	
	
	public SellOrderImpl(Stock stock) {
		this.stock = stock;
	}


	@Override
	public void execute() {
		stock.sellStock();
	}

}
