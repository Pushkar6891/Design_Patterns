package com.designpatterns.frontcontroller;

public class MainView {
    public void showView() {
        System.out.println("Showing main view.");
    }
}
