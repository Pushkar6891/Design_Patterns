package com.designpatterns.frontcontroller;

public class EmployeeView {
	public void showView() {
		System.out.println("Showing Employee view.");
	}
}