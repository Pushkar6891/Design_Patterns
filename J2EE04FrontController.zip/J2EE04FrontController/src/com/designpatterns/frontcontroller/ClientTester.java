package com.designpatterns.frontcontroller;

public class ClientTester {
	public static void main(String[] args) {
		FrontController frontController = new FrontController();
		frontController.dispatchRequest("MAIN");
		frontController.dispatchRequest("EMPLOYEE");
	}
}
