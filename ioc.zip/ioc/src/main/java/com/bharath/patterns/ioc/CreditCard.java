package com.bharath.patterns.ioc;

public interface CreditCard {

	void makePayment();
}
