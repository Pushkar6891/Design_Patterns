package com.bharath.patterns.ioc;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

public class IocApplicationTests {
	
	@Autowired
	Customer customer;

	@Test
	public void testPayment() {
		customer.pay();
	}

}
