module GOF03Behavioural10TemplateMethod {
}