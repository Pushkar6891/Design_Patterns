package com.designpatterns.kk;

public class NonVegPizza extends PizzaTemplate {

	@Override
	public void selectBread() {
		System.out.println("Choosing Bread for NonPizza");
	}

	@Override
	public void addIngredients() {
		System.out.println("Adding ingredients for NonPizza");
	}
	
	@Override
	public void cooking() {
		System.out.println("Cooking Pizza for 30 minutes");
	}

}
