package com.designpatterns.kk;

public abstract class PizzaTemplate {

	public abstract void selectBread();
	public abstract void addIngredients();
	
	public void cooking() {
		System.out.println("Cooking Pizza for 15 minutes");
	}
	
	public final void addingCheese() {
		System.out.println("Adding Cheese in Pizza");
	}
	
	public void addingToppings() {
		System.out.println("Adding Topping in Pizza");
	}
	
	public final void preparePizza() {
		selectBread();
		addIngredients();
		cooking();
		addingCheese();
		addingToppings();
	}
	
}
