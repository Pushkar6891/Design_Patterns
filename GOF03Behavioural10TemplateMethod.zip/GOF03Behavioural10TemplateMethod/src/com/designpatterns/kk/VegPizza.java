package com.designpatterns.kk;

public class VegPizza extends PizzaTemplate {

	@Override
	public void selectBread() {
		System.out.println("Choosing Bread for VegPizza");
	}

	@Override
	public void addIngredients() {
		System.out.println("Adding ingredients for VegPizza");
	}

}
