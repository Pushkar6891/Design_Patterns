package com.designpatterns.bharath;

public class Test {

	public static void main(String[] args) {

		DataRenderer dataRenderer = new XMLDataRenderer();
		dataRenderer.render();
	}

}
