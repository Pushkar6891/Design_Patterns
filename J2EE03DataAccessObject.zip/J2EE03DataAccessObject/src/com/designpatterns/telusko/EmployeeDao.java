package com.designpatterns.telusko;

import java.util.List;

public interface EmployeeDao {

	public Employee getEmployee(int empid);

	public List<Employee> getEmployees();

	public void createEmployee(Employee employee);

	public void updateEmployee(int empid, Employee employee);

	public void deleteEmployee(int empid);
}
