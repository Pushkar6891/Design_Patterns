package com.designpatterns.telusko;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDaoImpl implements EmployeeDao {

	public EmployeeDaoImpl() {

	}

	@Override
	public Employee getEmployee(int empid) {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/myteluskodb", "root",
					"Welcome@123");
			Statement st = conn.createStatement();
			String query = "select * from employee where empid=" + empid;
			ResultSet rs = st.executeQuery(query);
			while (rs.next()) {
				int empId = Integer.parseInt(rs.getString("empid"));
				String empName = rs.getString("empname");
				return new Employee(empId, empName);
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public List<Employee> getEmployees() {
		List<Employee> list = new ArrayList<>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/myteluskodb", "root",
					"Welcome@123");
			Statement st = conn.createStatement();
			String query = "select * from employee";
			ResultSet rs = st.executeQuery(query);
			while (rs.next()) {
				int empId = Integer.parseInt(rs.getString("empid"));
				String empName = rs.getString("empname");
				list.add(new Employee(empId, empName));
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public void createEmployee(Employee employee) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/myteluskodb", "root",
					"Welcome@123");
			String sql = "insert into employee values (?,?)";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, employee.getEmpid());
			ps.setString(2, employee.getEmpName());
			int i = ps.executeUpdate();
			System.out.println(i + " records inserted");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void updateEmployee(int empid, Employee employee) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/myteluskodb", "root",
					"Welcome@123");
			String sql = "update employee set empname=? where empid=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, employee.getEmpName());
			ps.setInt(2, empid);
			int i = ps.executeUpdate();
			System.out.println("Empid: " + empid + " has been updated");
			System.out.println(i + " records updated");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deleteEmployee(int empid) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/myteluskodb", "root",
					"Welcome@123");
			String sql = "delete from employee where empid=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, empid);
			int i = ps.executeUpdate();
			System.out.println("Empid: " + empid + " has been deleted");
			System.out.println(i + " records deleted");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

}
