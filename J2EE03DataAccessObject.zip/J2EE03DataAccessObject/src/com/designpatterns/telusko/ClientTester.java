package com.designpatterns.telusko;

import java.util.List;

public class ClientTester {

	public static void main(String[] args) {

		EmployeeDao employeeDao = new EmployeeDaoImpl();
		Employee employee = employeeDao.getEmployee(12);
		System.out.println(employee.getEmpid() + " " + employee.getEmpName());

		System.out.println("-".repeat(100));

		List<Employee> employees = employeeDao.getEmployees();
		employees.forEach(System.out::println);

		System.out.println("-".repeat(100));

	//	Employee newEmployee = new Employee(4, "Pushkar");
	//	employeeDao.createEmployee(newEmployee);

		System.out.println("-".repeat(100));

	//	Employee existingEmployee = employeeDao.getEmployee(4);
	//	existingEmployee.setEmpName("Gunjan");
	//	employeeDao.updateEmployee(existingEmployee.getEmpid(), existingEmployee);

		System.out.println("-".repeat(100));

	//	employeeDao.deleteEmployee(4);

		System.out.println("-".repeat(100));
	}

}
