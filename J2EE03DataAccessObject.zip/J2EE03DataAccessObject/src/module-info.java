module J2EE03DataAccessObject {
	requires java.sql;
}