module GOF02Structural06Flyweight {
}