package com.designpatterns.kk;

public class Laptop {

	private String ram;
	private String hdd;
	private String cpu;

	private boolean isGraphicsEnabled;
	private boolean isBluetoothEnabled;

	// Declare constructor as private
	private Laptop(LaptopBuilder laptopBuilder) {
		this.ram = laptopBuilder.ram;
		this.hdd = laptopBuilder.hdd;
		this.cpu = laptopBuilder.cpu;
		this.isBluetoothEnabled = laptopBuilder.isBluetoothEnabled;
		this.isGraphicsEnabled = laptopBuilder.isGraphicsEnabled;
	}

	public void setRam(String ram) {
		this.ram = ram;
	}

	public void setHdd(String hdd) {
		this.hdd = hdd;
	}

	public void setCpu(String cpu) {
		this.cpu = cpu;
	}

	public void setGraphicsEnabled(boolean isGraphicsEnabled) {
		this.isGraphicsEnabled = isGraphicsEnabled;
	}

	public void setBluetoothEnabled(boolean isBluetoothEnabled) {
		this.isBluetoothEnabled = isBluetoothEnabled;
	}

	@Override
	public String toString() {
		return "Laptop [ram=" + ram + ", hdd=" + hdd + ", cpu=" + cpu + ", isGraphicsEnabled=" + isGraphicsEnabled
				+ ", isBluetoothEnabled=" + isBluetoothEnabled + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}

	// create a nested LaptopBuilder Class which is static
	public static class LaptopBuilder {

		// make ram, hdd and cpu mandatory
		private String ram;
		private String hdd;
		private String cpu;

		private boolean isGraphicsEnabled;
		private boolean isBluetoothEnabled;

		public LaptopBuilder(String ram, String hdd, String cpu) {
			super();
			this.ram = ram;
			this.hdd = hdd;
			this.cpu = cpu;
		}

		// specify return type as LaptopBuilder
		public LaptopBuilder setGraphicsEnabled(boolean isGraphicsEnabled) {
			this.isGraphicsEnabled = isGraphicsEnabled;
			return this;
		}

		// specify return type as LaptopBuilder
		public LaptopBuilder setBluetoothEnabled(boolean isBluetoothEnabled) {
			this.isBluetoothEnabled = isBluetoothEnabled;
			return this;
		}

		// create a public build method
		public Laptop build() {
			return new Laptop(this);
		}

	}

}
