package com.designpatterns.kk;

public class ClientTester {

	public static void main(String[] args) {

		Laptop laptop1 = new Laptop.LaptopBuilder("16 GB", "240 GB", "2.56 GHZ").setBluetoothEnabled(true)
				.setGraphicsEnabled(true).build();
		System.out.println("Laptop 1 Configuartion: " + laptop1);

		Laptop laptop2 = new Laptop.LaptopBuilder("16 GB", "240 GB", "2.56 GHZ").setBluetoothEnabled(true)
				.setGraphicsEnabled(false).build();
		System.out.println("Laptop 2 Configuartion: " + laptop2);

		Laptop laptop3 = new Laptop.LaptopBuilder("16 GB", "240 GB", "2.56 GHZ").setBluetoothEnabled(false)
				.setGraphicsEnabled(true).build();
		System.out.println("Laptop 3 Configuartion: " + laptop3);

		Laptop laptop4 = new Laptop.LaptopBuilder("16 GB", "240 GB", "2.56 GHZ").build();
		System.out.println("Laptop 4 Configuartion: " + laptop4);

	}

}
