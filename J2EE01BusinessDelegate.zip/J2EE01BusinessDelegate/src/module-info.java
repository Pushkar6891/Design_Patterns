module J2EE01BusinessDelegate {
}