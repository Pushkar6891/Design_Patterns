package com.designpatterns.businessdelegate;

public class ClientTester {

	public static void main(String[] args) {

		BusinessDelegate businessDelegate = new BusinessDelegate();
		businessDelegate.setServiceType("EJB");

		Client client = new Client(businessDelegate);
		client.process();

		businessDelegate.setServiceType("JMS");
		client.process();

	}

}
