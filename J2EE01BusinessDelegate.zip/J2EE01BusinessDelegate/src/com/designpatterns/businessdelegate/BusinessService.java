package com.designpatterns.businessdelegate;

public interface BusinessService {
	public void process();
}
