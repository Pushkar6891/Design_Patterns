package com.designpatterns.kk;

public interface Collection {

	public abstract Iterator getIterator();
}
