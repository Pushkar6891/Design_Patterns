module GOF03Behavioural04Iterator {
}