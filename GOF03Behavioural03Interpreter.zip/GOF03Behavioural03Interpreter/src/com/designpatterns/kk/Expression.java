package com.designpatterns.kk;

public interface Expression {

	public abstract int interpret(InterpreterEngine interpreterEngine);
}
