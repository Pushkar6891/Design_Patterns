module GOF03Behavioural03Interpreter {
}