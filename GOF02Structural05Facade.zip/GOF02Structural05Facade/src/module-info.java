module GOF02Structural05Facade {
	requires java.sql;
}