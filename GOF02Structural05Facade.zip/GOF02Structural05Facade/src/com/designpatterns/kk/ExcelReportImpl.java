package com.designpatterns.kk;

import java.sql.Connection;

public class ExcelReportImpl implements ExcelReport {

	@Override
	public void generateExcelReport(Connection connection, String tablename) {
		System.out.println("Excel Report generation logic comes here ...");
	}

}
