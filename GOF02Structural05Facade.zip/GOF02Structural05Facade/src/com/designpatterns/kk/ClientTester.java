package com.designpatterns.kk;

import java.sql.Connection;

public class ClientTester {

	public static void main(String[] args) {

		Connection connection = null;
		String tablename = "employee_table";
		
		PDFReport pdfReport = new PDFReportImpl();
		pdfReport.generatePDFReport(connection, tablename);
		
		HTMLReport htmlReport = new HTMLReportImpl();
		htmlReport.generateHTMLReport(connection, tablename);
		
		ExcelReport excelReport = new ExcelReportImpl();
		excelReport.generateExcelReport(connection, tablename);
		
		System.out.println("================================================");
		
		ReportFacade reportFacade = new ReportFacade();
		reportFacade.generatePDFReport(connection, tablename);
		reportFacade.generateHTMLReport(connection, tablename);
		reportFacade.generateExcelReport(connection, tablename);
	}

}
