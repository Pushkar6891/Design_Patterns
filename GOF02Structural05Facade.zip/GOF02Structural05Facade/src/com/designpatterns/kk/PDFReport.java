package com.designpatterns.kk;

import java.sql.Connection;

public interface PDFReport {

	public abstract void generatePDFReport(Connection connection, String tablename);
	
}
