package com.designpatterns.kk;

import java.sql.Connection;

public class ReportFacade {

	private PDFReport pdfReport;
	private HTMLReport htmlReport;
	private ExcelReport excelreport;

	public ReportFacade() {
		pdfReport = new PDFReportImpl();
		htmlReport = new HTMLReportImpl();
		excelreport = new ExcelReportImpl();
	}
	
	public void generatePDFReport(Connection connection, String tablename) {
		System.out.println("PDF Report generation logic comes here ...");
	}
	
	public void generateHTMLReport(Connection connection, String tablename) {
		System.out.println("HTML Report generation logic comes here ...");
	}
	
	public void generateExcelReport(Connection connection, String tablename) {
		System.out.println("Excel Report generation logic comes here ...");
	}

}
