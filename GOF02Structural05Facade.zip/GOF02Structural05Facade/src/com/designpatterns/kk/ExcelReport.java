package com.designpatterns.kk;

import java.sql.Connection;

public interface ExcelReport {

	public abstract void generateExcelReport(Connection connection, String tablename);
	
}
