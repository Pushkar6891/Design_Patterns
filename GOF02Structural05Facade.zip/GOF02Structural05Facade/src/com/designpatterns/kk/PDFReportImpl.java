package com.designpatterns.kk;

import java.sql.Connection;

public class PDFReportImpl implements PDFReport {

	@Override
	public void generatePDFReport(Connection connection, String tablename) {
		System.out.println("PDF Report generation logic comes here ...");
	}

}
