package com.designpatterns.kk;

import java.sql.Connection;

public interface HTMLReport {

	public abstract void generateHTMLReport(Connection connection, String tablename);
	
}
