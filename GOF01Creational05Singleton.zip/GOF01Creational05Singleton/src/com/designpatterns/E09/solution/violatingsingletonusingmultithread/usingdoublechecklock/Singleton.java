package com.designpatterns.E09.solution.violatingsingletonusingmultithread.usingdoublechecklock;

public class Singleton {

	// 1. Lazy Initialization of static Singleton instance and marking volatile
	private static volatile Singleton singletonInstance = null;

	// 2. Make constructor as private
	private Singleton() {
		System.out.println("Creating Singleton instance...");
	}

	// 3. Provide a single static method getInstance()
	public static Singleton getInstance() {
		// Lazy Initialization
		// Two instances might see that singletonInstance is null and each thread
		// will end up creating new Singleton instance hence violating
		// sole instance requirement
		
		// Double Check Locking
		if (singletonInstance == null) {	// Check 1
			synchronized (Singleton.class) {
				if (singletonInstance == null) {	// Check 2
					singletonInstance = new Singleton();
				}
			}
		}
		return singletonInstance;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
}
