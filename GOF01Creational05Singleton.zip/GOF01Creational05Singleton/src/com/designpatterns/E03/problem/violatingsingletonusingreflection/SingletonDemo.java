package com.designpatterns.E03.problem.violatingsingletonusingreflection;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class SingletonDemo {
	public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		// Using Reflection to violate Singleton Design Pattern
		Class clazz = Class.forName(
				"com.designpatterns.creational.singleton003.problem.violatingsingletonusingreflection.Singleton");
		Constructor declaredConstructor = clazz.getDeclaredConstructor();
		declaredConstructor.setAccessible(true);
		Singleton s3 = (Singleton) declaredConstructor.newInstance();

		Singleton s1 = Singleton.getInstance();
		Singleton s2 = Singleton.getInstance();

		System.out.println("s1: " + s1.hashCode());
		System.out.println("s2: " + s2.hashCode());

		System.out.println("s3: " + s3.hashCode());
	}
}
