package com.designpatterns.E01.hashcode;

public class SingletonDemo {
	public static void main(String[] args) {

		// Cannot create object as Singleton constructor is private
		// Singleton s1 = new Singleton();

		Singleton s1 = Singleton.getInstance();
		Singleton s2 = Singleton.getInstance();

		System.out.println("s1: " + s1.hashCode());
		System.out.println("s2: " + s2.hashCode());
	}
}
