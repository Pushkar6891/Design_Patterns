package com.designpatterns.E05.solution.violatingsingletonusingserializationdeserialization.usingreadresolve;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.InvocationTargetException;

public class SingletonDemo {
	public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException {

		// Cannot create object as Singleton constructor is private
		// Singleton s1 = new Singleton();

		Singleton s1 = Singleton.getInstance();
		Singleton s2 = Singleton.getInstance();
		
		System.out.println("s1: " + s1.hashCode());
		System.out.println("s2: " + s2.hashCode());
		
		// Using Serialization to violate Singleton Design Pattern
		String fileNameSer = "Singleton.ser";
		File fileSer = new File(fileNameSer);
		FileOutputStream fos = new FileOutputStream(fileSer);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(s2);
		
		//Using Deserialization to violate Singleton Design Pattern
		// Reading Object Back
		String fileNameDeser = "Singleton.ser";
		File fileDeser = new File(fileNameDeser);
		FileInputStream fis = new FileInputStream(fileDeser);
		ObjectInputStream ois = new ObjectInputStream(fis);
		Singleton s3 = (Singleton) ois.readObject();
		
		System.out.println("s3: " + s3.hashCode());
		
		oos.close();
		ois.close();
	}
}
