package com.designpatterns.E02.problem.violatingsingletonusingreflection;

public class Singleton {
	// 1. Eager Initialization of static Singleton instance
	private static Singleton singletonInstance = new Singleton();

	// 2. Make constructor as private
	private Singleton() {
		System.out.println("Creating Singleton instance...");
	}
	
	// 3. Provide a single static method getInstance()
	public static Singleton getInstance() {
		return singletonInstance;
	}
}
