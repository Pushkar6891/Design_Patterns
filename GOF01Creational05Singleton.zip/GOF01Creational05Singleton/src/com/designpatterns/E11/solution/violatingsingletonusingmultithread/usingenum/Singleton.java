package com.designpatterns.E11.solution.violatingsingletonusingmultithread.usingenum;

enum Singleton {
	INSTANCE;
	
	public String getConfiguration() {
		return "Some Configuration";
	}
}


