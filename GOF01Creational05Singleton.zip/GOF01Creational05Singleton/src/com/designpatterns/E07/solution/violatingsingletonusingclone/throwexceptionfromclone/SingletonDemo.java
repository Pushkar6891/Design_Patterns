package com.designpatterns.E07.solution.violatingsingletonusingclone.throwexceptionfromclone;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class SingletonDemo {
	public static void main(String[] args)
			throws ClassNotFoundException, NoSuchMethodException, SecurityException, InstantiationException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException, CloneNotSupportedException {

		// Cannot create object as Singleton constructor is private
		// Singleton s1 = new Singleton();

		Singleton s1 = Singleton.getInstance();
		Singleton s2 = Singleton.getInstance();
		
		System.out.println("s1: " + s1.hashCode());
		System.out.println("s2: " + s2.hashCode());
		
		// Using Clone to violate Singleton
		Singleton s3 = (Singleton) s2.clone();

		System.out.println("s3: " + s3.hashCode());

	}
}
