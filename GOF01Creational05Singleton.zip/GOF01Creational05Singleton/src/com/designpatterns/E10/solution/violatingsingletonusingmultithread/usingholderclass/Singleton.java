package com.designpatterns.E10.solution.violatingsingletonusingmultithread.usingholderclass;

public class Singleton {

	// 1. Lazy Initialization of static Singleton instance and marking volatile
	private static volatile Singleton singletonInstance = null;

	// 2. Make constructor as private
	private Singleton() {
		System.out.println("Creating Singleton instance...");
	}

	// 3. Provide a single static method getInstance()
	public static Singleton getInstance() {
		return Holder.INSTANCE;
	}
	
	// Singleton Holder
	// Create Holder Static Class using Lazy Initialization
	static class Holder {
		static final Singleton INSTANCE = new Singleton();
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
}


