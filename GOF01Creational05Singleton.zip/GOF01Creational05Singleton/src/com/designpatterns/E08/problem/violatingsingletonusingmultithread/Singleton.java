package com.designpatterns.E08.problem.violatingsingletonusingmultithread;

public class Singleton {

	// 1. Lazy Initialization of static Singleton instance
	private static Singleton singletonInstance = null;

	// 2. Make constructor as private
	private Singleton() {
		System.out.println("Creating Singleton instance...");
	}

	// 3. Provide a single static method getInstance()
	public static Singleton getInstance() {
		// Lazy Initialization
		// Two instances might see that singletonInstance is null and each thread
		// will end up creating new Singleton instance hence violating
		// sole instance requirement
		if (singletonInstance == null) {
			singletonInstance = new Singleton();
		}
		return singletonInstance;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
}
