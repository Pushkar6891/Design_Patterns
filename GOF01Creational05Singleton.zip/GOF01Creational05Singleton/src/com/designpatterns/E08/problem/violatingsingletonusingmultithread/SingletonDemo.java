package com.designpatterns.E08.problem.violatingsingletonusingmultithread;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SingletonDemo {
	public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException,
			IOException, CloneNotSupportedException {

		ExecutorService executorService = Executors.newFixedThreadPool(2);
		executorService.submit(SingletonDemo::useSingleton);// creating two threads using java 8
		executorService.submit(SingletonDemo::useSingleton);
		executorService.shutdown();

	}

	public static void useSingleton() {
		Singleton singleton = Singleton.getInstance();
		System.out.println(singleton.hashCode());
	}
}
