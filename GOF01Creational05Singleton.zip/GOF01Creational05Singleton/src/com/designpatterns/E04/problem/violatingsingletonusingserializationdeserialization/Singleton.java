package com.designpatterns.E04.problem.violatingsingletonusingserializationdeserialization;

import java.io.Serializable;

public class Singleton implements Serializable {

	private static final long serialVersionUID = 1L;
	
	// 1. Eager Initialization of static Singleton instance
	private static Singleton singletonInstance = new Singleton();

	// 2. Make constructor as private
	private Singleton() {
		System.out.println("Creating Singleton instance...");
	}
	
	// 3. Provide a single static method getInstance()
	public static Singleton getInstance() {
		return singletonInstance;
	}
}
