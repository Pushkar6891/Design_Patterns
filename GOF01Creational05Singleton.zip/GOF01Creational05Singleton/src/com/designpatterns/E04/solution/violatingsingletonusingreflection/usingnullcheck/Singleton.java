package com.designpatterns.E04.solution.violatingsingletonusingreflection.usingnullcheck;

public class Singleton {
	// 1. Eager Initialization of static Singleton instance
	private static Singleton singletonInstance = new Singleton();

	// 2. Make constructor as private
	private Singleton() {
		// Fixing For Reflection
		if(singletonInstance!=null) {
			throw new RuntimeException("Cannot create new instance, please use getInstance()");
		}
		System.out.println("Creating Singleton instance...");
	}
	
	// 3. Provide a single static method getInstance()
	public static Singleton getInstance() {
		return singletonInstance;
	}
}
