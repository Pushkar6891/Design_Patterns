module GOF01Creational05Singleton {
}