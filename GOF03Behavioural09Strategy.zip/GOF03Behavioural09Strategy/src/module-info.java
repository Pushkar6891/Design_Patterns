module GOF03Behavioural09Strategy {
}