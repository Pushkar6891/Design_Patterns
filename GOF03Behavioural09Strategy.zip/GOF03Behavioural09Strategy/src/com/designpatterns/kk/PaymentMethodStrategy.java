package com.designpatterns.kk;

public interface PaymentMethodStrategy {

	public abstract void pay(int amount);
}
