package com.designpatterns.kk;

public class ClientTester {

	public static void main(String[] args) {
		ShoppingCart cart = new ShoppingCart();

		Product product1 = new Product("Redmi Note 9 Pro", "UPC Code 1", 100);
		Product product2 = new Product("Realme 6", "UPC Code 2", 200);
		Product product3 = new Product("Poco X2", "UPC Code 3", 300);
		
		cart.addProduct(product1);
		cart.addProduct(product2);
		cart.addProduct(product3);

		// pay by paypal
		cart.pay(new PaypalPaymentMethodStrategy("pushkarchauhan91@gmail.com", "mypassword"));

		// pay by credit card
		cart.pay(new CreditCardPaymentMethodStrategy("Pankaj Kumar", "1234 5678 9234 8765", "786", "12/15"));
	}

}
