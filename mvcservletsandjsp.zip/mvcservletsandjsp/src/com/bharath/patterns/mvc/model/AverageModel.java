package com.bharath.patterns.mvc.model;

public class AverageModel {

	public int calculateAverage(int num1, int num2) {
		return (num1 + num2) / 2;
	}

}
