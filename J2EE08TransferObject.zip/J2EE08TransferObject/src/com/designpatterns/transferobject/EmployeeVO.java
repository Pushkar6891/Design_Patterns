package com.designpatterns.transferobject;

public class EmployeeVO {
	private int employeeId;
	private String name;

	public EmployeeVO(int employeeId, String name) {
		this.employeeId = employeeId;
		this.name = name;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int id) {
		this.employeeId = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
