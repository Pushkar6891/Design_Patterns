module J2EE08TransferObject {
}