package com.designpatterns.kk;

public interface ComputerAbstractFactory {

	public Computer createComputer();
}
