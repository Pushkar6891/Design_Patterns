package com.designpatterns.bharath;

public interface Dao {

	void save();
}
