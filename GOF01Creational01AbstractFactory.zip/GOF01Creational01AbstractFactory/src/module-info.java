module GOF01Creational01AbstractFactory {
}