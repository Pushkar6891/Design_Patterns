package com.designpatterns.compositeentity;

public class Manager {
	private String name;
	private String satisfaction;

	public void setSatisfaction(String satisfaction) {
		this.satisfaction = satisfaction;
	}

	public String getSatisfaction() {
		return satisfaction;
	}
}
