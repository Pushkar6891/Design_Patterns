package com.designpatterns.compositeentity;

public class Employee {
	private String name;
	private String jobSuccess;

	public void setJobSuccess(String jobSuccess) {
		this.jobSuccess = jobSuccess;
	}

	public String getJobSuccess() {
		return jobSuccess;
	}
}