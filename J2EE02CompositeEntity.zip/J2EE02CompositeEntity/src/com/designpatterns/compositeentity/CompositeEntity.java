package com.designpatterns.compositeentity;

public class CompositeEntity {
	private CoarseGrainedObject cgo = new CoarseGrainedObject();

	public void setData(String jobSuccess, String satisfaction) {
		cgo.setData(jobSuccess, satisfaction);
	}

	public String[] getData() {
		return cgo.getData();
	}
}
