package com.designpatterns.compositeentity;

public class ClientTester {
	public static void main(String[] args) {
		Client client = new Client();
		client.setData("Successful", "Satisfied");
		client.print();
		client.setData("Failed", "Unsatisfied");
		client.print();
	}
}
