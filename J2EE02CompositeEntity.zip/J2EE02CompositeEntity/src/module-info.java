module J2EE02CompositeEntity {
}