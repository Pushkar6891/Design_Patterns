package com.designpatterns.interceptingfilter;

public interface Filter {
    public void execute(String request);
}
