module GOF02Structural07Proxy {
}