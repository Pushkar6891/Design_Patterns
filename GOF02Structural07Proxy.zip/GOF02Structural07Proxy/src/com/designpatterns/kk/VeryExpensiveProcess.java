package com.designpatterns.kk;

public interface VeryExpensiveProcess {
	// Time Consuming process
	public abstract void process();
}
