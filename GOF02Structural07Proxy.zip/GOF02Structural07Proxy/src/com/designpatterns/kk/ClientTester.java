package com.designpatterns.kk;

public class ClientTester {

	public static void main(String[] args) {
		// Only one time heavy object is created
		VeryExpensiveProcess veryExpensiveProcess = new VeryExpensiveProcessProxy();
		veryExpensiveProcess.process();
		veryExpensiveProcess.process();
	}

}
