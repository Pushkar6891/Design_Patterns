package com.designpatterns.observer.filewrite;

public class ObserverMain {

	public static void main(String[] args) throws InterruptedException {
		SubjectRead sub = new SubjectRead();
		new MyObserver(sub);
		// sub.readfile();
		sub.filereader();

	}
}
