package com.designpatterns.observer.filewrite;

public abstract class ObserverRead {

	public abstract void update();
}
