package com.designpatterns.kk;
//immutable class
public final class Message {

	private final String message;

	public String getMessage() {
		return message;
	}

	public Message(String message) {
		this.message = message;
	}

}
