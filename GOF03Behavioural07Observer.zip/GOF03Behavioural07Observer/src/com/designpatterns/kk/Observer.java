package com.designpatterns.kk;

public interface Observer {
	public void updateObserver(Message message);
}
