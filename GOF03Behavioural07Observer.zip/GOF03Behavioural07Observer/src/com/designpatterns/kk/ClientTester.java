package com.designpatterns.kk;

public class ClientTester {

	public static void main(String[] args) {

		FirstMessageSubscriber firstMessageSubscriber = new FirstMessageSubscriber();
		SecondMessageSubscriber secondMessageSubscriber = new SecondMessageSubscriber();
		ThirdMessageSubscriber thirdMessageSubscriber = new ThirdMessageSubscriber();

		MessagePublisher messagePublisher = new MessagePublisher();

		messagePublisher.register(firstMessageSubscriber);
		messagePublisher.register(secondMessageSubscriber);

		// firstMessageSubscriber and secondMessageSubscriber will receive the update
		messagePublisher.notifyUpdate(new Message("This is First Message"));

		System.out.println("==============================");

		messagePublisher.unregister(firstMessageSubscriber);
		messagePublisher.register(thirdMessageSubscriber);

		// secondMessageSubscriber and thirdMessageSubscriber will receive the update
		messagePublisher.notifyUpdate(new Message("This is Second Message"));

		System.out.println("==============================");
	}
}
