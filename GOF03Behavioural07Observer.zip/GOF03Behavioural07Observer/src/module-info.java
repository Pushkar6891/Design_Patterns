module GOF03Behavioural07Observer {
}