package com.designpatterns.bharath;

public class WeatherFinderImpl implements WeatherFinder{

	@Override
	public int find(String city) {
		return 33;
	}

}
