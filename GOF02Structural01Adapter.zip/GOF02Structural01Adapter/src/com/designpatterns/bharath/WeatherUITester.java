package com.designpatterns.bharath;

public class WeatherUITester {

	public void showTemperature(int zipcode) {
		WeatherAdapter adapter = new WeatherAdapter();
		int temperature = adapter.findTemperature(zipcode);
		System.out.println(temperature);
	}
	
	public static void main(String args[]) {
		WeatherUITester weatherUI = new WeatherUITester();
		weatherUI.showTemperature(19406);
	}
}
