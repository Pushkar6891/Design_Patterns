package com.designpatterns.bharath;

public interface WeatherFinder {

	int find(String city);
}
