package com.designpatterns.kk;

public class ClientTester {

	public static void main(String[] args) {

		WallSocket wallSocket = new WallSocketImpl();
		Volt v240 = wallSocket.getVolts();
		System.out.println(v240.getVolts());
		
		// Convert 220 to 5 volt
		MobileAdapter mobileAdapter = new MobileAdapterImpl(wallSocket);
		Volt v5 = mobileAdapter.getVolts();
		System.out.println(v5.getVolts());
	}

}
