package com.designpatterns.kk;

public interface WallSocket {
	public abstract Volt getVolts();
}
