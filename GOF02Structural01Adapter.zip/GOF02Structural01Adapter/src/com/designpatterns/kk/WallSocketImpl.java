package com.designpatterns.kk;

public class WallSocketImpl implements WallSocket {

	@Override
	public Volt getVolts() {
		return new Volt(220);
	}

}
