package com.designpatterns.kk;

public class MobileAdapterImpl implements MobileAdapter {

	private WallSocket wallSocket;

	public MobileAdapterImpl(WallSocket wallSocket) {
		this.wallSocket = wallSocket;
	}

	@Override
	public Volt getVolts() {
		Volt v220 = wallSocket.getVolts();
		int v5 = v220.getVolts()/44;
		return new Volt(v5);
	}

}
