package com.designpatterns.kk;

public interface MobileAdapter {
	public abstract Volt getVolts();
}
