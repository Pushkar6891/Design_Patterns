module GOF02Structural01Adapter {
}