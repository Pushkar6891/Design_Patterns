package com.designpatterns.kk;

public class ClientTester {

	public static void main(String[] args) {

		Blue blue = new Blue();
		Shape square = new Square(blue);
		String blueSquare = square.draw();
		System.out.println(blueSquare);

		System.out.println("==========================");

		Red red = new Red();
		Shape rectangle = new Rectangle(red);
		String redRectangle = rectangle.draw();
		System.out.println(redRectangle);

		System.out.println("==========================");
	}

}
