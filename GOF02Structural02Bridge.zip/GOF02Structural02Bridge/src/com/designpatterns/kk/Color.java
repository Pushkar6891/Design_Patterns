package com.designpatterns.kk;

public interface Color {
	public abstract String fill();
}
