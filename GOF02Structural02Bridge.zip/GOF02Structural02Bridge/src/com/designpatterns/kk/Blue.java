package com.designpatterns.kk;

public class Blue implements Color {

	@Override
	public String fill() {
		return "Color is Blue";
	}

}
