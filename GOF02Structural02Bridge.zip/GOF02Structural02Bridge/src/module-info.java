module GOF02Structural02Bridge {
}