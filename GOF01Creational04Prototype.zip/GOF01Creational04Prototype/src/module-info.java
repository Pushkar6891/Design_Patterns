module GOF01Creational04Prototype {
}