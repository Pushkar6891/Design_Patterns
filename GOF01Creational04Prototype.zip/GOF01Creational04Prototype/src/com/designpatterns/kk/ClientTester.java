package com.designpatterns.kk;

import java.util.List;

public class ClientTester {

	public static void main(String[] args) throws CloneNotSupportedException {

		EmployeeDAO employeeDAO = new EmployeeDAO();
		
		List<Employee> allEmployeesFromDB = employeeDAO.getAllEmployeesFromDB();
		
		System.out.println("Original Employee List : ");
		allEmployeesFromDB.forEach(System.out::println);
		
		System.out.println("=================");
		
		List<Employee> updatedEmployeeList = employeeDAO.clone();
		Employee employee = new Employee();
		employee.setId(30);
		employee.setName("SK");
		updatedEmployeeList.add(employee);
		
		System.out.println("Updated Employee List : ");
		updatedEmployeeList.forEach(System.out::println);
		
		System.out.println("=================");
	}

}
