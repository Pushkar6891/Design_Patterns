package com.designpatterns.kk;

import java.util.ArrayList;
import java.util.List;

public class EmployeeDAO implements Cloneable {

	private static List<Employee> employeeList;

	static {
		employeeList = new ArrayList<>();

		Employee employee1 = new Employee();
		employee1.setId(10);
		employee1.setName("PK");

		Employee employee2 = new Employee();
		employee2.setId(20);
		employee2.setName("MK");

		employeeList.add(employee1);
		employeeList.add(employee2);
	}

	public List<Employee> getAllEmployeesFromDB() {
		return employeeList;
	}

	@Override
	public List<Employee> clone() throws CloneNotSupportedException {

		List<Employee> dummyEmployeeList = new ArrayList<>();
		for (Employee employee : employeeList) {
			dummyEmployeeList.add(employee);
		}

		return dummyEmployeeList;
	}
}
