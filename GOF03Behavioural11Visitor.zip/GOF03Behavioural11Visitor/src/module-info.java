module GOF03Behavioural11Visitor {
}