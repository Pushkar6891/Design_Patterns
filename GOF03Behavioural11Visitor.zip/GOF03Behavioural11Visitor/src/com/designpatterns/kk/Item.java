package com.designpatterns.kk;

public interface Item {
	public double accept(ShoppingCartVisitor visitor);
}
