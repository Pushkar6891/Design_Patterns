package com.designpatterns.kk;

public class VisitorClientTester {

	public static void main(String[] args) {

		Item items[] = new Item[] { new Book("Core Java", "1234", 450.0), new Book("Hibernate", "6789", 700.0),
				new Fruit("Mango", 2, 100), new Fruit("Apple", 3, 200) };

		double totalCost = calculatePrice(items);
		System.out.println("Total Cost = " + totalCost);
	}

	private static double calculatePrice(Item[] items) {
		ShoppingCartVisitor visitor = new ShoppingCartVisitorImpl();
		double totalCost = 0.0;
		for (Item item : items) {
			totalCost = totalCost + item.accept(visitor);
		}
		return totalCost;
	}
}
