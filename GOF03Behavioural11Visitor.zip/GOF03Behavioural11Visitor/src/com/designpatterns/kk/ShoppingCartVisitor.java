package com.designpatterns.kk;

public interface ShoppingCartVisitor {
	public double visit(Book book);

	public double visit(Fruit fruit);
}
