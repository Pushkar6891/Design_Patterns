package com.designpatterns.kk;

public class ShoppingCartVisitorImpl implements ShoppingCartVisitor {

	@Override
	public double visit(Book book) {
		double cost = 0.0;
		if (book.getPrice() > 500) {
			cost = book.getPrice() - 100; // 100 discout if price is greater than 500
		} else {
			cost = book.getPrice();
		}
		System.out.println(
				"Book Name: " + book.getName() + " Book ISBN: " + book.getIsbnNumber() + " Book Cost: " + cost);
		return cost;
	}

	@Override
	public double visit(Fruit fruit) {
		double cost = fruit.getPricePerKg() * fruit.getWeight();
		System.out.println("Fruit Name: " + fruit.getName() + " Fruit Cost: " + cost);
		return cost;
	}

}
