package com.designpatterns.visitor;

public interface ItemElement {
	public int accept(ShoppingCartVisitor visitor);
}