package com.designpatterns.bharath;

public interface ComputerPart {
	public void accept(ComputerPartVisitor visitor);
}