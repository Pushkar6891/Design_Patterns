package com.designpatterns.bharath;

public class VisitorPatternClientTester {

	public static void main(String[] args) {

		ComputerPart computer = new Computer();
		ComputerPartDisplayVisitorImpl visitor = new ComputerPartDisplayVisitorImpl();
		computer.accept(visitor);

	}

}
