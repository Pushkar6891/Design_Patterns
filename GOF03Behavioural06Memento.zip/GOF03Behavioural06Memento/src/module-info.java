module GOF03Behavioural06Memento {
}