package com.bharath.patterns.movietickets.services;

import com.bharath.patterns.movietickets.bo.Ticket;

public interface TicketService {
	
	void purchaseTicket(Ticket ticket);

}
