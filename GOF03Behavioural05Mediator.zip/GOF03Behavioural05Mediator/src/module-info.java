module GOF03Behavioural05Mediator {
}