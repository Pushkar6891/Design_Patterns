module GOF02Structural04Decorator {
}