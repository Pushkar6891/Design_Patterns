package com.designpatterns.kk;

public interface Bike {

	public abstract void assembleBike();
	
}
