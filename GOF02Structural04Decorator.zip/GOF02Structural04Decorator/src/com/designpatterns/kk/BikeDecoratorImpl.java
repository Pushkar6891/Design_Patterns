package com.designpatterns.kk;

public class BikeDecoratorImpl implements Bike {

	private Bike bike;
	
	public BikeDecoratorImpl(Bike bike) {
		this.bike = bike;
	}
	@Override
	public void assembleBike() {
		bike.assembleBike();
	}

}
