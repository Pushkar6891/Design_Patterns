package com.designpatterns.kk;

public class SportsBike extends BikeDecoratorImpl {

	public SportsBike(Bike bike) {
		super(bike);
	}
	
	@Override
	public void assembleBike() {
		super.assembleBike();
		System.out.println("Adding features of Sports Bike...");
	}
}
