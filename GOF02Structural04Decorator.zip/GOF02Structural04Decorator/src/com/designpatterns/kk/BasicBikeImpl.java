package com.designpatterns.kk;

public class BasicBikeImpl implements Bike {

	@Override
	public void assembleBike() {
		System.out.println("Adding features of Basic Bike...");
	}

}
