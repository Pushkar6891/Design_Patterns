package com.designpatterns.kk;

public class LuxuryBike extends BikeDecoratorImpl {

	public LuxuryBike(Bike bike) {
		super(bike);
	}
	
	@Override
	public void assembleBike() {
		super.assembleBike();
		System.out.println("Adding features of Luxury Bike...");
	}

}
