package com.designpatterns.kk;

public class ClientTester {

	public static void main(String[] args) {

		Bike basicBike = new BasicBikeImpl();
		basicBike.assembleBike();
		
		System.out.println("=========================");
		
		Bike sportsBike = new SportsBike(new BasicBikeImpl());
		sportsBike.assembleBike();
		
		System.out.println("=========================");
		
		Bike luxuryBike = new LuxuryBike(new BasicBikeImpl());
		luxuryBike.assembleBike();
		
		System.out.println("=========================");
		
		// Creating Bike with both sports and luxury bike
		Bike sportsLuxuryBike = new SportsBike(new LuxuryBike(new BasicBikeImpl()));
		sportsLuxuryBike.assembleBike();
		
		System.out.println("=========================");
	}
	
}
