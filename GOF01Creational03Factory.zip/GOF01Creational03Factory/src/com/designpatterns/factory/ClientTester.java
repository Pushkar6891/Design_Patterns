package com.designpatterns.factory;

public class ClientTester {

	public static void main(String[] args) {
		Computer pc = ComputerFactory.getComputer("pc", "2 GB", "500 GB", "2.4 GHz");
		Computer laptop = ComputerFactory.getComputer("laptop", "8 GB", "1 TB", "2.6 GHz");
		Computer server = ComputerFactory.getComputer("server", "16 GB", "100 TB", "2.9 GHz");
		System.out.println("Factory PC Config::" + pc);
		System.out.println("Factory Laptop Config::" + laptop);
		System.out.println("Factory Server Config::" + server);
	}
}
