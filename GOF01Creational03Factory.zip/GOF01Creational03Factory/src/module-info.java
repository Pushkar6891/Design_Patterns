module GOF01Creational03Factory {
}